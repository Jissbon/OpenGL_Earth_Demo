#include "GLTools.h"
#include "GLShaderManager.h"
#include "GLFrustum.h"
#include "GLBatch.h"
#include "GLMatrixStack.h"
#include "GLGeometryTransform.h"
#include "StopWatch.h"

#include <math.h>
#include <stdio.h>

#ifdef __APPLE__
#include <glut/glut.h>
#else
#define FREEGLUT_STATIC
#include <GL/glut.h>
#endif

GLShaderManager        shaderManager;            // 着色器管理器
GLMatrixStack        modelViewMatrix;        // 模型视图矩阵
GLMatrixStack        projectionMatrix;        // 投影矩阵
GLFrustum            viewFrustum;            // 视景体
GLGeometryTransform    transformPipeline;        // 几何图形变换管道

GLTriangleBatch        torusBatch;             //大球
GLTriangleBatch     sphereBatch;            //小球
GLBatch                floorBatch;          //地板

//角色帧 照相机角色帧
//GLFrame  cameraFrame;
GLFrame  objectFrame;



//**4、添加附加随机球
#define NUM_SPHERES 50
GLFrame spheres[NUM_SPHERES];

void SetupRC(){
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    shaderManager.InitializeStockShaders();
    
    glEnable(GL_DEPTH_TEST);
    
    floorBatch.Begin(GL_LINES, 324);
    for(GLfloat x = -20.0; x <= 20.0f; x+= 0.5) {
        floorBatch.Vertex3f(x, -0.55f, 20.0f);
        floorBatch.Vertex3f(x, -0.55f, -20.0f);
        
        floorBatch.Vertex3f(20.0f, -0.55f, x);
        floorBatch.Vertex3f(-20.0f, -0.55f, x);
    };
    
    floorBatch.End();
    
    objectFrame.MoveForward(15.0);
    
    //设置大球的顶点
    gltMakeSphere(torusBatch, 0.4f, 40, 80);
    
    //随机50个静止小球与一个旋转的小球
    gltMakeSphere(sphereBatch, 0.1f, 20, 40); //动态小球的
    
    //50个静态小球
    for (int i = 0; i<NUM_SPHERES; i++) {
        //在一个平面上面 ,说明小球的y坐标都是在同一平面的
        GLfloat x = ((GLfloat)((rand()%400)-200)*0.1);
        GLfloat z = ((GLfloat)((rand()%400)-200)*0.1);
        spheres[i].SetOrigin(x,0.0f,z);
    }
}



void RenderScence(void){
    
//    printf("红球在自转");
    
    
    
    static GLfloat vFloorColor[] = { 0.0f, 1.0f, 0.0f, 1.0f};
    static GLfloat vTorusColor[] = { 1.0f, 0.0f, 0.0f, 1.0f };
    static GLfloat vSpereColor[] = {0.0,1.0,1.0,1.0};
 
    //
    static CStopWatch    rotTimer;
    float yRot = rotTimer.GetElapsedSeconds() * 20.0;
    
    //清空缓存
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);

    //方法1:使用cameraFrame来展示
//    M3DMatrix44f mCamera;
//    cameraFrame.GetCameraMatrix(mCamera);
//    modelViewMatrix.PushMatrix(mCamera);
    
    //方法2: 使用objectFrame;
    modelViewMatrix.PushMatrix(objectFrame);
    
    
//   绘制地板
shaderManager.UseStockShader(GLT_SHADER_FLAT,transformPipeline.GetModelViewProjectionMatrix(),vFloorColor);
    floorBatch.Draw();
    
    //绘制中心大球
    //设定光源位置
    M3DVector4f vLightPos = {0.0,10.0,5.0,1.0};

    //球移动的方式,1.改变观察者 2.objectFrame变化  3.物体坐标移动
    modelViewMatrix.Translate(0.0f, 0.0f, -3.0f);
    
    modelViewMatrix.PushMatrix();
    
   modelViewMatrix.Rotate(yRot, 0.0f, 1.0f, 0.0f);
    
    shaderManager.UseStockShader(GLT_SHADER_POINT_LIGHT_DIFF, transformPipeline.GetModelViewMatrix(),
    transformPipeline.GetProjectionMatrix(), vLightPos, vTorusColor);

    torusBatch.Draw();
    
    //结束动作,出栈
    modelViewMatrix.PopMatrix();
    

    //画小球
    for (int i = 0; i<NUM_SPHERES; i++) {
        modelViewMatrix.PushMatrix(); //取得单元矩阵
        modelViewMatrix.MultMatrix(spheres[i]); //矩阵叉乘,其实就是平移
        shaderManager.UseStockShader(GLT_SHADER_POINT_LIGHT_DIFF,transformPipeline.GetModelViewMatrix(),transformPipeline.GetProjectionMatrix(),vLightPos,vSpereColor);
        sphereBatch.Draw();
        modelViewMatrix.PopMatrix();
    }

    //画公转的篮球
    modelViewMatrix.Rotate(yRot*2, 0.0f, 1.0f, 0.0f);
    modelViewMatrix.Translate(1.0,0.0, 0.0);
shaderManager.UseStockShader(GLT_SHADER_POINT_LIGHT_DIFF,transformPipeline.GetModelViewMatrix(),transformPipeline.GetProjectionMatrix(),vLightPos,vSpereColor);
    
//    modelViewMatrix.Rotate(yRot * -2.0f, 0.0f, 1.0f, 0.0f);
//    modelViewMatrix.Translate(0.8f, 0.0f, 0.0f);
//    shaderManager.UseStockShader(GLT_SHADER_FLAT,transformPipeline.GetModelViewProjectionMatrix(),vSpereColor);
    
    sphereBatch.Draw();
    modelViewMatrix.PopMatrix();

    
    //交换缓存
    glutSwapBuffers();
    
    //不断渲染
    glutPostRedisplay();
    
}

void ChangeSize(int w, int h){
    
    glViewport(0, 0, w, h);
    
    viewFrustum.SetPerspective(35.0,float(w)/float(h), 1.0, 100.0);
    
    projectionMatrix.LoadMatrix(viewFrustum.GetProjectionMatrix());
    
//    modelViewMatrixStack.LoadIdentity();//初始化代码可以不写
    
    transformPipeline.SetMatrixStacks(modelViewMatrix, projectionMatrix);
    
    
}


void SpecialKeys(int key,int x, int y){
    
    float liner = 0.5f;
    float angular = float(m3dDegToRad(5.0f));
    
    switch (key) {
        case GLUT_KEY_UP:
//            cameraFrame.MoveForward(liner);
            objectFrame.MoveForward(liner);
            break;
        case GLUT_KEY_DOWN:
//            cameraFrame.MoveForward(-liner);
            objectFrame.MoveForward(-liner);
            break;
        case GLUT_KEY_LEFT:
//            cameraFrame.RotateWorld(angular, 0, 1, 0);
//            cameraFrame.RotateLocalY(angular);
            objectFrame.RotateLocalY(angular);
            break;
        case GLUT_KEY_RIGHT:
//            cameraFrame.RotateWorld(-angular, 0, 1, 0);
//            cameraFrame.RotateLocalY(-angular);
            objectFrame.RotateLocalY(-angular);
            break;
        default:
            break;
    }
    
}



int main(int argc, char* argv[])
{
    gltSetWorkingDirectory(argv[0]);
    
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(800,600);
    
    glutCreateWindow("OpenGL SphereWorld");
    
    glutReshapeFunc(ChangeSize);
    glutDisplayFunc(RenderScence);
    
//    glutKeyboardFunc(KeyPressFunc);
    glutSpecialFunc(SpecialKeys);
    
    GLenum err = glewInit();
    if (GLEW_OK != err) {
        fprintf(stderr, "GLEW Error: %s\n", glewGetErrorString(err));
        return 1;
    }
    
    
    SetupRC();
    glutMainLoop();
    return 0;
}



